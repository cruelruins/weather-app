async function search() {
    const city = document.getElementById("search-input").value.trim();
    if (!city) {
        document.getElementById("error").textContent = "⚠ Syötä kaupungin nimi";
        return;
    }

    try {
        const res = await fetch(`/weather?city=${encodeURIComponent(city)}`);
        const data = await res.json();

        if (!res.ok || data.error) {
            document.getElementById("error").textContent = "⚠ " + (data.error || "Haku epäonnistui");
            return;
        }

        renderWeather(data);
    } catch (e) {
        document.getElementById("error").textContent = "⚠ Yhteys epäonnistui";
    }
}

function renderWeather(data) {
    document.getElementById("error").textContent = "";
    document.getElementById("city").textContent = data.city;
    document.getElementById("temp").textContent = data.temperature + "°C";
    document.getElementById("desc").textContent = data.description;
    document.getElementById("wind").textContent = "💨 " + data.wind_speed + " m/s";
    document.getElementById("humidity").textContent = "💧 " + data.humidity + "%";

    const iconEl = document.getElementById("icon");
    if (iconEl && data.icon) {
        iconEl.src = `https://openweathermap.org/img/wn/${data.icon}@2x.png`;
        iconEl.alt = data.description;
        iconEl.style.display = "block";
    }
}

const searchInput = document.getElementById("search-input");
const searchButton = document.getElementById("search-btn");

searchInput.addEventListener("keydown", e => {
    if (e.key === "Enter") search();
});

searchButton.addEventListener("click", search);
