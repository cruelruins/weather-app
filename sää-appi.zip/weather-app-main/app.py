from flask import Flask, request, jsonify
import requests
import os
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__, static_folder="frontend", static_url_path="")

API_KEY = os.getenv("API_KEY")

@app.route("/", methods=["GET"])
def index():
    return app.send_static_file("index.html")

@app.route("/weather", methods=["GET"])
def get_weather():

    city = request.args.get("city")

    if not city:
        return jsonify({
            "error": "Kaupungin nimi puuttuu"
        }), 400

    if not API_KEY:
        return jsonify({
            "error": "OpenWeather API_KEY puuttuu palvelimen ympäristömuuttujasta"
        }), 500

    url = (
        f"https://api.openweathermap.org/data/2.5/weather"
        f"?q={city}&appid={API_KEY}&units=metric&lang=fi"
    )

    try:
        response = requests.get(url)

        # Virhe: API ei vastaa oikein
        if response.status_code != 200:
            return jsonify({
                "error": "Kaupunkia ei löydy tai API-virhe"
            }), 404

        data = response.json()

        weather_data = {
            "city": data["name"],
            "temperature": data["main"]["temp"],
            "humidity": data["main"]["humidity"],
            "wind_speed": data["wind"]["speed"],
            "description": data["weather"][0]["description"],
            "icon": data["weather"][0]["icon"]
        }

        return jsonify(weather_data)

    except requests.exceptions.RequestException:
        return jsonify({
            "error": "Sääpalveluun ei saada yhteyttä"
        }), 500


if __name__ == "__main__":
    app.run(debug=True)